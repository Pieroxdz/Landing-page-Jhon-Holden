package com.IsilERP.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.IsilERP.dao.ProveedorDAO;
import com.IsilERP.model.Proveedor;

/**
 * Servlet implementation class ProveedorController
 */
@WebServlet("/proveedor")
public class ProveedorController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ProveedorDAO proveedorDAO = new ProveedorDAO();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProveedorController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String opcion = request.getParameter("opcionGet");
		switch (opcion) {
			case "buscarProveedores": {
				try {
					buscarProveedores(request,response);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			}
		}
	}
	
	private void buscarProveedores(HttpServletRequest request,HttpServletResponse response) throws SQLException {
		String ruc = request.getParameter("ruc");
		String razonSocial = request.getParameter("razonSocial");
		List<Proveedor> listaProveedores = proveedorDAO.buscarProveedorxRucxRazonSocial(ruc, razonSocial);
		request.setAttribute("listaProveedores", listaProveedores);
		/*Esto se realiza cuando quieres pasar a otra página */
		String paginaDestino = "/gestionProveedores.jsp";
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(paginaDestino);
		try {
			dispatcher.forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}

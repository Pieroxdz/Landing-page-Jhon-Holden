package com.IsilERP.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.IsilERP.dao.UsuarioDAO;
import com.IsilERP.model.Usuario;

/**
 * Servlet implementation class UsuarioController
 */
@WebServlet("/usuario")
public class UsuarioController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UsuarioDAO usuarioDAO = new UsuarioDAO();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UsuarioController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String opcion = request.getParameter("opcionGet");
		switch (opcion){
			case "buscarUsuarios" : {
				buscarUsuarios(request,response);
				break;
			}
			case "eliminarUsuario": {
				try {
					eliminarUsuario(request,response);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			}
			case "mostrarEditarUsuario": {
				try {
					mostrarEditarUsuario(request,response);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			}
		}
	}

	private void mostrarEditarUsuario(HttpServletRequest request,HttpServletResponse response) throws SQLException {
		int id = Integer.parseInt(request.getParameter("id"));
		Usuario objUsuario = usuarioDAO.buscarxId(id);
		request.setAttribute("objUsuario", objUsuario);
		/*Esto se realiza cuando quieres pasar a otra página */
		String paginaDestino = "/editarUsuario.jsp";
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(paginaDestino);
		try {
			dispatcher.forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public void eliminarUsuario(HttpServletRequest request,HttpServletResponse response) throws SQLException {
		int id = Integer.parseInt(request.getParameter("id"));
		usuarioDAO.eliminarUsuario(id);
		/*Esto se realiza cuando quieres pasar a otra página */
		String paginaDestino = "/gestionUsuarios.jsp";
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(paginaDestino);
		try {
			dispatcher.forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void buscarUsuarios(HttpServletRequest request,HttpServletResponse response) {
		String correoBuscar = request.getParameter("correo");
		List<Usuario> listaUsuarios = usuarioDAO.buscarUsuarios(correoBuscar);
		request.setAttribute("listaUsuarios", listaUsuarios);
		/*Esto se realiza cuando quieres pasar a otra página */
		String paginaDestino = "/gestionUsuarios.jsp";
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(paginaDestino);
		try {
			dispatcher.forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String opcion = request.getParameter("opcionPost");
		switch (opcion) {
			case "mostrarNuevoUsuario": {
				mostrarNuevoUsuario(request,response);
				break;
			}
			case "grabarNuevoUsuario": {
				try {
					grabarNuevoUsuario(request,response);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			}
			case "actualizarUsuario":{
				try {
					actualizarUsuario(request,response);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			}
		}
	}
	
	private void actualizarUsuario(HttpServletRequest request,HttpServletResponse response) throws SQLException {
		int id = Integer.parseInt(request.getParameter("id"));
		String correo = request.getParameter("correo");
		String password = request.getParameter("password");
		String estado = request.getParameter("estado");
		usuarioDAO.actualizarUsuario(id, correo, password, estado);
		/*Esto se realiza cuando quieres pasar a otra página */
		String paginaDestino = "/gestionUsuarios.jsp";
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(paginaDestino);
		try {
			dispatcher.forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void grabarNuevoUsuario(HttpServletRequest request,HttpServletResponse response) throws SQLException {
		String paginaDestino;
		String correo = request.getParameter("correo");
		String password = request.getParameter("password");
		String estado = request.getParameter("estado");
		int existeCorreo = usuarioDAO.validarExisteCorreo(correo);
		if (existeCorreo==1) {
			paginaDestino = "/nuevoUsuario.jsp";
		}
		else {
			usuarioDAO.registrarNuevoUsuario(correo,password,estado);
			paginaDestino = "/gestionUsuarios.jsp";
		}
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(paginaDestino);
		try {
			dispatcher.forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void mostrarNuevoUsuario(HttpServletRequest request,HttpServletResponse response) {
		/*Esto se realiza cuando quieres pasar a otra página */
		String paginaDestino = "/nuevoUsuario.jsp";
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(paginaDestino);
		try {
			dispatcher.forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}

package com.IsilERP.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.IsilERP.model.Proveedor;

public class ProveedorDAO {
	private String url; /*Cadena de conexion a la base de datos*/
	private Connection conexion; /*La conexion a la base de datos*/
	
	/*Metodo constructor de la clase*/
	public ProveedorDAO() {
		/*Definimos la cadena de conexion a la base de datos*/
		/*La cadena de conexion es: jdbc:sqlserver://ubicacionBD:puerto;databaseName=nombreBD,usuarioBD,passwordBD*/
		this.url = "jdbc:sqlserver://localhost:1433;databaseName=IsilERP;user=sa;password=sa";
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			this.conexion = DriverManager.getConnection(url);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public List<Proveedor> buscarProveedorxRucxRazonSocial(String ruc, String razonSocial) throws SQLException{
		List<Proveedor> listaProveedores = new ArrayList();
		CallableStatement cs = this.conexion.prepareCall("{CALL SP_buscarxRUCxRazonSocial(?,?)}");
		cs.setString(1, ruc);
		cs.setString(2, razonSocial);
		ResultSet rs = cs.executeQuery();
		while (rs.next()) {
			Proveedor objProveedor = new Proveedor();
			objProveedor.setId(rs.getInt(1));
			objProveedor.setRazonSocial(rs.getString(2));
			objProveedor.setRuc(rs.getString(3));
			objProveedor.setDireccion(rs.getString(4));
			objProveedor.setCiudad(rs.getString(5));
			objProveedor.setEstado(rs.getString(6));
			listaProveedores.add(objProveedor);
		}
		rs.close();
		return listaProveedores;
	}
}

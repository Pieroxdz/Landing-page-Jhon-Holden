package com.IsilERP.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.IsilERP.model.Usuario;

public class UsuarioDAO {
	private String url; /*Cadena de conexion a la base de datos*/
	private Connection conexion; /*La conexion a la base de datos*/
	
	/*Metodo constructor de la clase*/
	public UsuarioDAO() {
		/*Definimos la cadena de conexion a la base de datos*/
		/*La cadena de conexion es: jdbc:sqlserver://ubicacionBD:puerto;databaseName=nombreBD,usuarioBD,passwordBD*/
		this.url = "jdbc:sqlserver://localhost:1433;databaseName=IsilERP;user=sa;password=sa";
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			this.conexion = DriverManager.getConnection(url);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public int validarUsuario(String correo, String password) {
		String sentenciaSQL = "select * from Usuario where correo='" + correo + "' and password='" + password + "' and estado='Activo'";
		Statement stmt;
		int esValido = 0; //Voy a partir pensando que no es valido
		try {
			stmt = this.conexion.createStatement();
			ResultSet rs = stmt.executeQuery(sentenciaSQL);
			while (rs.next()) {
				esValido = 1; //Si entro al while es porque si trajo al menos un registro
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return esValido;
	}

	public int validarExisteCorreo(String correo) {
		String sentenciaSQL = "select * from Usuario where correo='" + correo + "'";
		Statement stmt;
		int esValido = 0; //Voy a partir pensando que no es valido
		try {
			stmt = this.conexion.createStatement();
			ResultSet rs = stmt.executeQuery(sentenciaSQL);
			while (rs.next()) {
				esValido = 1; //Si entro al while es porque si trajo al menos un registro
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return esValido;
	}
	
	public List<Usuario> buscarUsuarios(String correoBuscar){
		String sentenciaSQL = "select * from Usuario where correo like '%" + correoBuscar +"%'";
		Statement stmt;
		List<Usuario> listaUsuarios = new ArrayList<Usuario>();
		try {
			stmt = this.conexion.createStatement();
			ResultSet rs = stmt.executeQuery(sentenciaSQL);
			while (rs.next()) {
				int id = rs.getInt(1);
				String correo = rs.getString(2);
				String password = rs.getString(3);
				String estado = rs.getString(4);
				Usuario objUsuario = new Usuario();
				objUsuario.setId(id);
				objUsuario.setCorreo(correo);
				objUsuario.setPassword(password);
				objUsuario.setEstado(estado);
				listaUsuarios.add(objUsuario);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listaUsuarios;
	}
	
	public void eliminarUsuario(int id) throws SQLException {
		String sentenciaSQL = "delete from Usuario where id=" + id;
		Statement stmt;
		stmt = this.conexion.createStatement();
		stmt.execute(sentenciaSQL);
	}
	
	public void registrarNuevoUsuario(String correo, String password, String estado) throws SQLException {
		String sentenciaSQL = "insert into Usuario(correo,password,estado) values (?,?,?)";
		PreparedStatement stmt;
		stmt = this.conexion.prepareStatement(sentenciaSQL);
		stmt.setString(1, correo);
		stmt.setString(2, password);
		stmt.setString(3, estado);
		stmt.execute(); /*El execute a secas lo utilizamos para insert, update, delete"*/
	}
	
	public Usuario buscarxId(int id) throws SQLException {
		Usuario objUsuario = new Usuario(); //Este es el objUsuario donde devolveré el resultado
		String sentenciaSQL = "select * from Usuario where id=?";
		PreparedStatement stmt;
		stmt = this.conexion.prepareStatement(sentenciaSQL);
		stmt.setInt(1, id);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			objUsuario.setId(rs.getInt(1));
			objUsuario.setCorreo(rs.getString(2));
			objUsuario.setPassword(rs.getString(3));
			objUsuario.setEstado(rs.getString(4));
		}
		rs.close();
		return objUsuario;
	}
	
	public void actualizarUsuario(int id, String correo, String password, String estado) throws SQLException{
		String sentenciaSQL = "update Usuario set correo=?, password=?, estado=? where id=?";
		PreparedStatement stmt;
		stmt = this.conexion.prepareStatement(sentenciaSQL);
		stmt.setString(1, correo);
		stmt.setString(2, password);
		stmt.setString(3, estado);
		stmt.setInt(4, id);
		stmt.execute();
	}
}
